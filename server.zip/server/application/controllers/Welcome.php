<?php
// defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	public function __construct() {
		parent::__construct();
		$this->load->model('login_model');
	}

	// main entry point to program. 
	// runs when you visit corona.uqcloud.net/test or 
	// corona.uqcloud.net/test/welcome
	// returns array containing user state
	public function index() {
		
		// $this->register();
		// get the post details when logging in
		$username = $this->input->post('username');
		$password = $this->input->post('password');

		if (isset($username) && isset($password) && strlen($username) > 0) {
			$deets = $this->login_model->getUserDetails($username, $password);

			echo json_encode($deets);
		}

	}

	// Returns the scores for the classroom given by the user's id
	public function getScores() {
		$user_id = $this->input->post('user_id');
		$result = $this->login_model->getClassDetails($user_id);

		echo json_encode($result);
	}

	// Saves the gamestate given by the parameters to the db
	// corona.uqcloud.net/test/welcome/save
	public function save() {
		$user_id = $this->input->post('user_id');
		$currentHealth = $this->input->post('currentHealth');
		$abilityPoints = $this->input->post('abilityPoints');
		$activeScene = $this->input->post('activeScene');
		$coins = $this->input->post('coins');
		$characterCount = $this->input->post('characterCount');

		$this->login_model->updateValues($user_id, $currentHealth, $abilityPoints, $activeScene, $coins, $characterCount);
	}

	// registers the user
	// corona.uqcloud.net/test/welcome/register
	public function register() {
		// get the post details when logging in
		$username = $this->input->post('username');
		$password = $this->input->post('password');
		$code = $this->input->post('code');

		// check if the username is a duplicate
		if ($this->login_model->countUsers($username) != "duplicate") {
			if (isset($username) && isset($password) && strlen($username) > 0) {
					$result = $this->login_model->addUser($username, $password, $code);
			}
			echo "success";
			return;
		}
		echo "fail";
	}

	

}
