<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Login_model extends CI_Model
{

	public function __construct()
	{
		$this->load->database();
	}


	// gets the user's details
	public function getUserDetails($username, $password) {
		$query = "select * from users where username = ?"; 
		$result = $this->db->query($query, array($username))->row();
		if (!isset($result)) {
			return false;	
		}
		// // return true if valid
		if ($password == $result->password) {
			unset($result->password);
			return $result;
			// return array($result->user_id, $result->currentHealth, $result->abilityPoints, $result->activeScene);
		}
		return false;
	}


	/** Gets all classmates and their details */
	public function getClassDetails($user_id) {
		$query = "select users.user_id as user_id, username, currentHealth, coins, abilityPoints from users, classroom where users.user_id = classroom.user_id and classroom.room_code = (SELECT room_code FROM `classroom` WHERE user_id = ?) order by currentHealth desc, coins desc, abilityPoints desc";
		$result = $this->db->query($query, array($user_id));
		return $result->result_array();
	}

	// Updates the user's details
	public function updateValues($user_id, $currentHealth, $abilityPoints, $activeScene, $coins, $characterCount) {
		$query = "update users set currentHealth = ?, abilityPoints = ?, activeScene = ?, coins = ?, characterCount = ? where user_id = ? ";
		$result = $this->db->query($query, array($currentHealth, $abilityPoints, $activeScene, $coins, $characterCount,$user_id));
	}

	// creates user account with supplied username and password
	public function addUser($username, $password, $code) {
		$query = "insert into users (username, password, currentHealth, abilityPoints, activeScene, coins, characterCount) values (?, ?, ?, ?, ?, ?, ?)";
		$defaulthealth = 10;
		$defaultpoints = 3;
		$defaultscene = 1;
		$defaultCoins = 20;
		$defaultCharacterCount = 1;
		$this->db->query($query, array($username, $password, $defaulthealth, $defaultpoints, $defaultscene, $defaultCoins, $defaultCharacterCount));

		
		// get the added userid
		$maxidquery = "select max(user_id) as id from users";
		$userid = $this->db->query($maxidquery)->row()->id;

		// add to classroom too
		if (isset($code) && strlen($code) != 0) {
			$classquery = "insert into classroom (room_code, user_id) values (?, ?)";
			$this->db->query($classquery, array($code, $userid));
		}
	}

	// Counts the number of users which have the same username
	public function countUsers($username) {
		$query = "select count(*) as a from users where username = ?";
		$result = $this->db->query($query, array($username))->row()->a;

		if ($result != 0) {
			return "duplicate";
		}
		return "good";
	}
	
}
